package com.example.cs_360_project_fernish;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        TextView txtUsername = findViewById(R.id.userNameText);
        TextView txtPassword = findViewById(R.id.passwordText);

        Button btnLogin = findViewById(R.id.btnLogIn);

        btnLogin.setOnClickListener(l -> {
            String username = txtUsername.getText().toString();
            String password = txtPassword.getText().toString();

            AuthenticatedUser user = new AuthenticatedUser("joe_jones");

            AuthenticatedUserManger.getInstance().setUser(user);
        });
    }
}
