package com.example.cs_360_project_fernish;

import java.util.Objects;

public class Inventory {

    private final long id;
    private String name;
    private String description;

    /**
     * Get the id
     * @return - the id
     */
    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Inventory(long id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public Inventory(String name, String description){
        this(-1, name, description);
    }

    public Inventory(long id, Inventory inventory){
        this(id, inventory.name, inventory.description);
    }

    public Inventory(Inventory i) {
        this(i.id, i.name, i.description);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Inventory inventory = (Inventory) o;
        return id == inventory.id && Objects.equals(name, inventory.name) && Objects.equals(description, inventory.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, description);
    }
}