package com.example.cs_360_project_fernish;

public class AuthenticatedUser {

    private static String username;

    public AuthenticatedUser(String username){
        this.username = username;
    }

    public static String getUsername(){
        return username;
    }
}
