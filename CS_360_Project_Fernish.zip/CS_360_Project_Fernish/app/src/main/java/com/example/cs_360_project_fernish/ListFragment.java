package com.example.cs_360_project_fernish;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class ListFragment extends Fragment implements DetailsFragment.ItemListener {

    private InventoryAdapter adapter;

    @Override
    public void handleEdited(Inventory original, Inventory edited) {
        adapter.editItem(original, edited);
    }

    @Override
    public void handleDeleted(Inventory deleted) {
        adapter.deleteItem(deleted);
    }

    // For the activity to implement
    public interface OnInventorySelected {
        void onInventorySelected(int itemId);

    }

    // Reference to the activity
    private OnInventorySelected mListener;

    public ListFragment(){
        DetailsFragment.register(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnInventorySelected) {
            mListener = (OnInventorySelected) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnInventorySelectedListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.item_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        // Send bands to recycler view
        adapter = new InventoryAdapter();
        recyclerView.setAdapter(adapter);

        FloatingActionButton fab = view.findViewById(R.id.floating_action_button);

        fab.setOnClickListener(l -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
            builder.setTitle("Add Item");

            View editView = inflater.inflate(R.layout.inventory_details, null);
            builder.setView(editView);

            EditText txtDescription = editView.findViewById(R.id.txtItemDescription);
            EditText txtName = editView.findViewById(R.id.txtItemName);

            builder.setPositiveButton("OK", (dialogInterface, i) -> {
                String name = txtName.getText().toString();
                String description = txtDescription.getText().toString();
                Inventory inventory = new Inventory(name, description);
                long result = InventoriesDatabase.getInstance(getContext()).addItem(inventory);

                if (result == -1) {
                    Toast.makeText(getContext(), "Item name already exists", Toast.LENGTH_SHORT).show();
                } else {
                    adapter.addItem(new Inventory(result, inventory));
                }
            });

            builder.setNegativeButton("Cancel", null);
            builder.create();

            builder.show();
        });

        return view;
    }

    private class ItemHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private Inventory mInventory;

        private final TextView mNameTextView;

        public ItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.list_item_inventory, parent, false));
            itemView.setOnClickListener(this);
            mNameTextView = itemView.findViewById(R.id.lblItemName);
        }

        public void bind(Inventory inventory) {
            mInventory = inventory;
            mNameTextView.setText(mInventory.getName());
        }

        @Override
        public void onClick(View view) {
            // Tell ListActivity what item was clicked
            mListener.onInventorySelected((int)mInventory.getId());
        }
    }

    private class InventoryAdapter extends RecyclerView.Adapter<ItemHolder> {

        private final List<Inventory> mInventory;

        public InventoryAdapter() {
            mInventory = InventoriesDatabase.getInstance(getContext()).getItems(AuthenticatedUserManger.getInstance().getUser());
        }

        @Override
        public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ItemHolder holder, int position) {
            Inventory inventory = mInventory.get(position);
            holder.bind(inventory);
        }

        @Override
        public int getItemCount() {
            return mInventory.size();
        }

        public void addItem(Inventory inventory){
            mInventory.add(inventory);
            notifyItemInserted(mInventory.size() - 1);
        }

        public void editItem(Inventory original, Inventory edited){
            int index = mInventory.indexOf(original);

            mInventory.add(index, edited);
            mInventory.remove(original);
            notifyItemChanged(index);
        }

        public void deleteItem(Inventory inventory){
            int index = mInventory.indexOf(inventory);
            mInventory.remove(inventory);
            notifyItemRemoved(index);
        }
    }


}