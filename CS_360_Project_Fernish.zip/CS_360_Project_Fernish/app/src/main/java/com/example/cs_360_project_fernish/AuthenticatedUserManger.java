package com.example.cs_360_project_fernish;

public class AuthenticatedUserManger {

    private AuthenticatedUser user;

    private static AuthenticatedUserManger instance;

    private AuthenticatedUserManger() {

    }

    /**
     * Get the singleton instance
     * @return - the singleton instance
     * @thorws - IllegalStateException if not initialized
     */
    public static AuthenticatedUserManger getInstance(){
        if (instance == null){
            instance = new AuthenticatedUserManger();
        }
        return instance;
    }

    /**
     * get the authenticated user
     * @return - the @AuthenticatedUser
     */

    public AuthenticatedUser getUser(){
        return user;
    }

    /**
     * Set the Authenticated user
     * @param user - the @AuthenticatedUser
     */
    public void setUser(AuthenticatedUser user){
        this.user = user;
    }
}
