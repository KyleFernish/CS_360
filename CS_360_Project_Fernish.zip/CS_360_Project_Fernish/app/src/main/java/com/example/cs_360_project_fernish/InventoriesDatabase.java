package com.example.cs_360_project_fernish;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class InventoriesDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "inventories.db";

    private static InventoriesDatabase instance;

    InventoriesDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static InventoriesDatabase getInstance(Context context){
        if (instance == null){
            instance = new InventoriesDatabase(context);
        }

        return instance;
    }

    private static final class InventoriesTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_DESCRIPTION = "description";

        private static final String COL_USERNAME = "username";
    }

    private static final class LogInTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";

        private static final String COL_PASSWORD = "password";

        private static final String COL_USERNAME = "username";
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + InventoriesTable.TABLE + "( " +
                InventoriesTable.COL_ID + " integer primary key autoincrement, " +
                InventoriesTable.COL_NAME + ", " +
                InventoriesTable.COL_USERNAME + ", " +
                InventoriesTable.COL_DESCRIPTION + ")");

        db.execSQL("create table " + LogInTable.TABLE + "( " +
                LogInTable.COL_ID + " integer primary key autoincrement, " +
                LogInTable.COL_USERNAME + ", " +
                LogInTable.COL_PASSWORD + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoriesTable.TABLE);
        onCreate(db);
    }
//Add authenticated user parameter to getItems() getItem() etc
    public List<Inventory> getItems(AuthenticatedUser username){
        List<Inventory> inventories = new ArrayList<>();

        SQLiteDatabase db = getReadableDatabase();

        String sql = "SELECT * FROM " + InventoriesTable.TABLE + " WHERE " + InventoriesTable.COL_USERNAME + " = ?";

        Cursor cursor = db.rawQuery(sql, new String[]{String.username}); //new string array with username

        if (cursor.moveToFirst()){
            do {
                long id = cursor.getInt(0);
                String name = cursor.getString(1);
                String description = cursor.getString(2);
                Inventory inventory = new Inventory(id, name, description);
                inventories.add(inventory);
            } while (cursor.moveToNext());
        }

        return inventories;
    }
//add authenticated user same as above
    public Inventory getItem(long itemId){
        Inventory inventory = null;

        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + InventoriesTable.TABLE + " WHERE " + InventoriesTable.COL_ID + " = ?";  //Use above w/o .toString String.username
        Cursor cursor = db.rawQuery(sql, new String[]{Long.toString(itemId)});

        if (cursor.moveToFirst()){

            String name = cursor.getString(1);
            String description = cursor.getString(2);
            inventory = new Inventory(itemId, name, description);
        }

        return inventory;
    }
//add auth user as parameter
    public long addItem(Inventory inventory){

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoriesTable.COL_NAME, inventory.getName());
        values.put(InventoriesTable.COL_DESCRIPTION, inventory.getDescription());
        values.put(InventoriesTable.COL_USERNAME, AuthenticatedUser.getUsername());
        //username
        long newId = db.insert(InventoriesTable.TABLE, null, values);

        return newId;
    }

    public boolean editItem(long id, Inventory inventory){
        boolean isEdited = false;
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoriesTable.COL_ID, id);
        values.put(InventoriesTable.COL_NAME, inventory.getName());
        values.put(InventoriesTable.COL_DESCRIPTION, inventory.getDescription());
        values.put(InventoriesTable.COL_USERNAME, AuthenticatedUser.getUsername());
        //username concatenate username inside where clause

        int result = db.update(InventoriesTable.TABLE, values, InventoriesTable.COL_USERNAME + " = " + AuthenticatedUser.getUsername(), null);

        return result == 1;
    }

    public boolean deleteItem(long id){
        SQLiteDatabase db = getWritableDatabase();
        //username concatenate username inside where clause

        int result = db.delete(InventoriesTable.TABLE, InventoriesTable.COL_USERNAME + " = " + AuthenticatedUser.getUsername(), null);
        return result == 1;
    }

    //ToDo Log In Method

    public boolean logIn(AuthenticatedUser username){
        SQLiteDatabase db = getWritableDatabase();

        

    //ToDo Register Method
}